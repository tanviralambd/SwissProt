package uni.constant;

import java.util.regex.Pattern;

public class  ConstantValue {

	


	

	// LOCAL LINUX
//	public static String filePrefixLinux="/media/Data/KAUST/research/CNC/CNCnorepeat/data/";
//	public static String filePrefixLinuxWithrpt="/media/Data/KAUST/research/CNC/CNCwithrepeat/data/";
//	public static String filePrefixReview="/media/Data/KAUST/research/test//data/";
//	public static String filePrefixChIPSeq="/media/Data/KAUST/research/CNC/CNCnorepeat/data/dataChipseq/";
	// KAUST MACHINE

	public static String Seperator_Comma=",";
	public static String Seperator_SemiColon=";";
	
	

	
	public static Pattern patTabSingle = Pattern.compile("[\\t]");
	
	public static Pattern patTab = Pattern.compile("[\\t]+");
	public static Pattern patWhiteSpace = Pattern.compile("[\\s]+");
	public static Pattern patNewline = Pattern.compile("[\\n]+");
	
	public static Pattern patHyphen = Pattern.compile("[-]+");
	public static Pattern patUnderscore = Pattern.compile("[_]+");	
	public static Pattern patColon = Pattern.compile("[:]+");	
	public static Pattern patSemiColon = Pattern.compile("[;]+");	
	public static Pattern patCSV = Pattern.compile("[,]+");
	
	public static Pattern patHash = Pattern.compile("[#]+");
	public static Pattern patAngle = Pattern.compile("[>]+");
	public static Pattern patFastaHeader = Pattern.compile("[>_]+");	
	public static Pattern patFantom5Cage = Pattern.compile("[:.,]+");	
	public static Pattern patGeneBankEntry = Pattern.compile("//");
	
	
	public static Pattern patTransfacMatch = Pattern.compile("[|]+");	
	public static Pattern patUNIPROT = Pattern.compile("[_]+");
	public static Pattern patHOCOMOCO = Pattern.compile("[_+!]+"); // 
	// GABP1+GABP2_HUMAN , NFIA+NFIB+NFIC+NFIX_HUMAN , NFIA+NFIB+NFIC+NFIX_HUMAN ZBTB4!METH_HUMAN 	ATF2+ATF4_HUMAN
	
	public static String hocomocoPostFix = "_HUMAN";
	
	
	public static String noneStr="None";
	public static String noneVal="0.0";
	
	////
	
	
	public static Pattern pat_without_0hr = Pattern.compile("pool");
	public static Pattern pat_with_0hr = Pattern.compile("poolWith");

	public static Pattern pat_without_2hr = Pattern.compile("without(.)+02hr");
	public static Pattern pat_with_2hr = Pattern.compile("with%20Mtb(.)+02hr");
	
	
	public static Pattern pat_without_4hr = Pattern.compile("without(.)+04hr");
	public static Pattern pat_with_4hr = Pattern.compile("with%20Mtb(.)+04hr");
	
	
	public static Pattern pat_without_6hr = Pattern.compile("without(.)+06hr");
	public static Pattern pat_with_6hr = Pattern.compile("with%20Mtb(.)+06hr");
	
	
	public static Pattern pat_without_12hr = Pattern.compile("without(.)+012hr");
	public static Pattern pat_with_12hr = Pattern.compile("with%20Mtb(.)+012hr");
	
	
	public static Pattern pat_without_24hr = Pattern.compile("without(.)+024hr");
	public static Pattern pat_with_24hr = Pattern.compile("with%20Mtb(.)+024hr");
	
	
	
	public static Pattern pat_without_28hr = Pattern.compile("without(.)+028hr");
	public static Pattern pat_with_28hr = Pattern.compile("with%20Mtb(.)+028hr");
	
	public static Pattern pat_without_36hr = Pattern.compile("without(.)+036hr");
	public static Pattern pat_with_36hr = Pattern.compile("with%20Mtb(.)+036hr");
	
	public static Pattern pat_without_48hr = Pattern.compile("without(.)+048hr");
	public static Pattern pat_with_48hr = Pattern.compile("with%20Mtb(.)+048hr");
	
	public static Pattern pat_without_72hr = Pattern.compile("without(.)+072hr");
	public static Pattern pat_with_72hr = Pattern.compile("with%20Mtb(.)+072hr");
	
	public static Pattern pat_without_120hr = Pattern.compile("without(.)+0120hr");
	public static Pattern pat_with_120hr = Pattern.compile("with%20Mtb(.)+0120hr");
	
	public static String head_Without[] = {	"Without_Mtb_0_hr", 
		"Without_Mtb_2_hr" , "Without_Mtb_4_hr" , "Without_Mtb_6_hr" , "Without_Mtb_12_hr" , "Without_Mtb_24_hr" ,  
		"Without_Mtb_28_hr", "Without_Mtb_36_hr", "Without_Mtb_48_hr", "Without_Mtb_72_hr" , "Without_Mtb_120_hr" };
	
	public static String head_With[] = {	"With_Mtb_0_hr", 
		"With_Mtb_2_hr" , "With_Mtb_4_hr" , "With_Mtb_6_hr" , "With_Mtb_12_hr" , "With_Mtb_24_hr" ,  
		"With_Mtb_28_hr", "With_Mtb_36_hr", "With_Mtb_48_hr", "With_Mtb_72_hr" , "With_Mtb_120_hr" };
	

	
public static int  SAMPLESIZE = 20339 ;  // 9730 , 10609
	
	
	public static int 	SEQLEN= 2000;
	public static int WINDOWSIZE = 100;
	public static int  WINDOWSHIFT = 50;
	public static int WINDOW_TOTAL = 39;
	public static int RANDSEQSIZE = 1000;
	
	public static int NO_CS_STATE = 15;
	
	public static int NO_HM_ANTIBODY = 1;
	
	
	public static int upStream = 1000;
	public static int downStream = 1000;
	
	public static String fileRefseqOriginalWindows= "D:/KAUST/research/CNC/CNCnorepeat/data/refseq.bed";
	public static String fileRefseqOriginalLinux= "/media/Data/KAUST/research/CNC/CNCnorepeat/data/refseq.bed";
	
	
	public static String filePrefixWindows="D:/KAUST/research/CNC/CNCnorepeat/dataUsedREFPS/";
	
	// LOCAL LINUX
//	public static String filePrefixLinux="/media/Data/KAUST/research/CNC/CNCnorepeat/data/";
//	public static String filePrefixLinuxWithrpt="/media/Data/KAUST/research/CNC/CNCwithrepeat/data/";
//	public static String filePrefixReview="/media/Data/KAUST/research/test//data/";
//	public static String filePrefixChIPSeq="/media/Data/KAUST/research/CNC/CNCnorepeat/data/dataChipseq/";
	// KAUST MACHINE
	public static String filePrefixLinux="/home/KAUST/alamt/CNC/CNCnorepeat/data/";
	public static String filePrefixLinuxWithrpt="/home/KAUST/alamt/CNC/CNCwithrepeat/data/";
	public static String filePrefixReview="/home/KAUST/research/test//data/";
	public static String filePrefixChIPSeq="/home/KAUST/alamt/CNC/CNCnorepeat/data/dataChipseq/";
	// CBRC CLUSTER+ LINUX
//	public static String filePrefixLinux="/media/Data/KAUST/research/CNC/CNCnorepeat/data/";
	
	public static String RPT_SIMPLE = "Simple_repeat";
	public static String RPT_SATELLITE = "Satellite";
	public static String RPT_LOWCOMPLEXITY = "Low_complexity";
	public static String STRAND_DONTCARE=".";

	
	

	public static Pattern patSemiColonComma  = Pattern.compile("[,;]+");
	public static Pattern patSemiColon_Comma = Pattern.compile("[;,]+");
	

	
	
	public static String fantomTissue="tissue";
	public static String fantomPrimaryCell="primary_cell";
	public static String NotApplStr="NA";

	////
	
	public static int human_total_Chromosome = 24;
	
	
	public static String seperatorList = ";";
	
	
	
}
