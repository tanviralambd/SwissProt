package uni.parsing;



import java.util.Vector;

import uni.common.CommonFunction;
import uni.constant.ConstantValue;

/*
 *  Select only entries with NM_/NT_/ENST/ENSG
 */
public class Select_Refseq_Ensembl_Mapping {



	String fnmHumanSwissprotMap;
	String fnmHumanSwissprotMapSelected;


	public Select_Refseq_Ensembl_Mapping(String fnmHumanSwissprotMap,
			String fnmHumanSwissprotMapSelected) {
		super();
		this.fnmHumanSwissprotMap = fnmHumanSwissprotMap;
		this.fnmHumanSwissprotMapSelected = fnmHumanSwissprotMapSelected;
	}



	void doProcessing()
	{

		Vector<String> vectTarbase = CommonFunction.readlinesOfAfile(this.fnmHumanSwissprotMap);
		StringBuffer resBuffer = new StringBuffer();
		String tmp[];

		String swissprotID, otherDbID;

		for(int i=1 ; i<vectTarbase.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectTarbase.get(i));

			swissprotID = tmp[0];
			otherDbID = tmp[2];
			
			if(swissprotID.contains("-") ){
				swissprotID = swissprotID.substring(0, swissprotID.indexOf("-")) ;
			}
			

			if( otherDbID.startsWith("NM_")   ||   otherDbID.startsWith("NP_")  
					|| otherDbID.startsWith("ENSG")  || otherDbID.startsWith("ENST")   )
			{
				if(otherDbID.contains(".") ){
					otherDbID = otherDbID.substring(0, otherDbID.indexOf(".")) ;
				}else if(otherDbID.contains("-") ){
					otherDbID = otherDbID.substring(0, otherDbID.indexOf("-")) ;
				}
				
				resBuffer.append(swissprotID +"\t" + otherDbID + "\n");
				
				
			}
			



		}


		CommonFunction.writeContentToFile(this.fnmHumanSwissprotMapSelected, resBuffer+"");

	}

	public static void main(String[] args) {

		Select_Refseq_Ensembl_Mapping obj = new Select_Refseq_Ensembl_Mapping(args[0] , args[1]);
		//		

//		SelectFromHumanMapping obj = new SelectFromHumanMapping("/run/media/tanviralam/Data/research/F5shortRNA/dataCommon/swissprot/HUMAN_9606_idmapping.dat",
//				"/run/media/tanviralam/Data/research/F5shortRNA/dataCommon/swissprot/HUMAN_9606_idmapping.Selected.dat");

		obj.doProcessing();

	}

}

