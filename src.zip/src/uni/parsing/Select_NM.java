package uni.parsing;

import java.util.Vector;

import uni.common.CommonFunction;
import uni.constant.ConstantValue;

public class Select_NM {

	
	String input;
	String output;
	
	
	
	
	public Select_NM(String input, String output) {
		super();
		this.input = input;
		this.output = output;
	}

	void doProcessing()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.input);
		
		String tmp[];
		StringBuffer buf = new StringBuffer();
		for(int i=0; i<vectAll.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			if( tmp[3].startsWith("NM_")) 
			{
				
				buf.append(vectAll.get(i) + "\n");
			}
			
			
		}
		
		
		CommonFunction.writeContentToFile(this.output, buf+"");
		
		
		
	}
	
	public static void main(String[] args) {
		
		Select_NM obj = new Select_NM("refGene.hg19.txt", "refGene_NM.hg19.txt");
		
		obj.doProcessing();
		
	}
	
}
