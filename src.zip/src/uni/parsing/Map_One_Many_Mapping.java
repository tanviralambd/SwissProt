package uni.parsing;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import uni.common.CommonFunction;
import uni.constant.ConstantValue;

public class Map_One_Many_Mapping {


	String fnmInput;
	String fnmOut;
	String key0based;
	String value0based;


	void doProcessing()
	{




		LinkedHashMap<String, Set<String>> lhm_Key_valueSet = new LinkedHashMap<String, Set<String>>();


		lhm_Key_valueSet = CommonFunction.readlinesOfAfile_asMap_setValue(this.fnmInput, 
				Integer.parseInt(this.key0based), Integer.parseInt(this.value0based) );


		StringBuffer resBuf = new StringBuffer();

		Set set = lhm_Key_valueSet.entrySet();
		System.out.println("Total Unique entry:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			String id = (String)me.getKey();
			Set mySet = (Set<String>) me.getValue();

			if(mySet.size() > 0)
			{


				resBuf.append( id +"\t");

				String[] arr = (String[]) mySet.toArray(new String[mySet.size()]);
				int setSize = arr.length;
				for(int c=0; c < setSize;c++)
				{
					if(c==setSize-1)
						resBuf.append(arr[c]+"\n");
					else
						resBuf.append(arr[c]+ ";");

				} 
			}
		}


		CommonFunction.writeContentToFile(this.fnmOut, resBuf+"");
		
		
		

	}





	public Map_One_Many_Mapping(String fnmInput, String fnmOut,
			String fnmKey0based, String fnmValue0based) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOut = fnmOut;
		this.key0based = fnmKey0based;
		this.value0based = fnmValue0based;
	}





	public static void main(String[] args) {

		Map_One_Many_Mapping obj = new Map_One_Many_Mapping(args[0], args[1], args[2], args[3]);
		
//		Map_One_Many_Mapping obj = new Map_One_Many_Mapping("refgeneNM_swissprot_human_download.tab",
//				"out.txt", "0", "1");

		obj.doProcessing();

	}

}
