package uni.parsing;

import java.util.Vector;

import uni.common.CommonFunction;
import uni.constant.ConstantValue;

public class OneLinePerRefseq {

	String fnmInput;
	String fnmOut;
	
	
	
	
	public OneLinePerRefseq(String fnmInput, String fnmOut) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOut = fnmOut;
	}

	void doProcessing()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);
		
		String tmp[] , tmpRefseqEn[];
		String uniEntry, uniName;
		
		StringBuffer buf = new StringBuffer();
		for(int i=0; i<vectAll.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			uniEntry = tmp[0];
			uniName  = tmp[1];
			tmpRefseqEn = ConstantValue.patCSV.split(tmp[2]);
			
			for( int j=0 ; j<tmpRefseqEn.length ;j++)
			{
				
				buf.append( tmpRefseqEn[j] + "\t" + uniName + "\t" + uniEntry +  "\n");
			}
			
			
		}
		
		
		CommonFunction.writeContentToFile(this.fnmOut, buf+"");
		
		
	}
	
	public static void main(String[] args) {
//		
//		OneLinePerRefseq obj = new OneLinePerRefseq("swissprot_refgeneNM_human_download.tab" , 
//				"refgeneNM_swissprot_human_download.tab");
		

		OneLinePerRefseq obj = new OneLinePerRefseq(args[0] , args[1]);
		obj.doProcessing();
		
		
	}
	
	
}
