package uni.parsing;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import uni.common.CommonFunction;
import uni.constant.ConstantValue;

public class Uniprot_Refseq_MultipleMapping {

	String mappingUniToRefseq;
	String bedRefseq ;
	String multiple_mapping;

	
	
	
	public Uniprot_Refseq_MultipleMapping(String mappingUniToRefseq, String bedRefseq,
			String multiple_mapping) {
		super();
		this.mappingUniToRefseq = mappingUniToRefseq;
		this.bedRefseq = bedRefseq;
		this.multiple_mapping = multiple_mapping;
	}


	LinkedHashMap<String, Set<String> > lhm_Uni_Refseq = new LinkedHashMap<String, Set<String>>();
	LinkedHashMap<String, Set<String>> lhm_Name_FullLineBed = new LinkedHashMap<String, Set<String>>() ;


	void loadUniRefseqID()
	{
		String tmp[];
		String curLine , curName;
		String  uniprotID, refseqIDWithVersion, refseqIDWithoutVersion;
		/*
		 *  Load uniprot -> set of RefseqNM
		 */
		
		Vector<String>  vectIDmap = new Vector<String>();
		vectIDmap = CommonFunction.readlinesOfAfile( this.mappingUniToRefseq);

		for(int i=0; i<vectIDmap.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectIDmap.get(i));
			uniprotID = tmp[0];
			refseqIDWithVersion=tmp[1];
			refseqIDWithoutVersion = refseqIDWithVersion.substring(0,  refseqIDWithVersion.lastIndexOf('.') ) ;

			if(lhm_Uni_Refseq.containsKey(uniprotID))
			{
				//				System.out.println("Already exist: " + tmp[0]);
				((Set)lhm_Uni_Refseq.get(uniprotID ) ).add( refseqIDWithoutVersion )  ;

			}else
			{
				Set tmpSet = new LinkedHashSet<String>();
				tmpSet.add(refseqIDWithoutVersion);
				lhm_Uni_Refseq.put( uniprotID, tmpSet );
			}
		}
		System.out.println("Total unique entry in swissprot name: " + lhm_Uni_Refseq.size());
	}


	void loadrefseqName_BedMapping()
	{

		String tmp[];
		String curLine , curName;
		String  uniprotID, refseqIDWithVersion, refseqIDWithoutVersion;


		/*
		 *  Load refseqName -> set of sequence
		 */
		Vector<String>  vectBED = new Vector<String>();
		vectBED = CommonFunction.readlinesOfAfile( this.bedRefseq);

		for(int i=0; i<vectBED.size();i++)
		{
			curLine = vectBED.get(i) ;
			tmp = ConstantValue.patTab.split(  curLine);
			refseqIDWithoutVersion = tmp[3];


			if(lhm_Name_FullLineBed.containsKey(refseqIDWithoutVersion))
			{
				//				System.out.println("Already exist: " + refseqIDWithoutVersion);
				((Set)lhm_Name_FullLineBed.get(refseqIDWithoutVersion ) ).add( curLine )  ;
			}else
			{


				Set tmpSet = new LinkedHashSet<String>();
				tmpSet.add(curLine);
				lhm_Name_FullLineBed.put(refseqIDWithoutVersion, tmpSet );

			}

		}
		System.out.println("Total unique name in bed file: " + lhm_Name_FullLineBed.size());


	}


	void make_Uniprot_Refseq_Mapping()
	{


		// Now select those bedlines matching with Uniprot ID 
		/*
		 *  TO DO
		 */

		StringBuffer bufResult = new StringBuffer();
		Vector<String>  vectResult = new Vector<String>();

		Set setUni = lhm_Uni_Refseq.entrySet();

		Iterator itrUni = setUni.iterator();
		while(itrUni.hasNext()){

			Map.Entry me = (Map.Entry) itrUni.next();

			String curUni = (String)me.getKey();
			Set<String> setRefseq = (Set<String>) me.getValue();

			bufResult.append(curUni+"\t");


			Iterator itrRef = setRefseq.iterator();
			String curRefID;
			StringBuffer tmpBuffer = new StringBuffer();
			while( itrRef.hasNext())
			{
				curRefID = (String)itrRef.next();

				tmpBuffer.append(curRefID+",");
			}

			bufResult.append( tmpBuffer.substring(0, tmpBuffer.length()-1) + "\n");
			


		}


		CommonFunction.writeContentToFile( this.multiple_mapping , bufResult+"");

	}


	/*
	 * mappingUniToRefseq : UNIPROTid | RefseqID
	 * bedRefseq : Refseq in Bed format
	 * uniID : UniprotID in one column
	 */

	void doProcessing()
	{
		
		loadUniRefseqID();
		loadrefseqName_BedMapping();
		make_Uniprot_Refseq_Mapping();
	}


	public static void main(String[] args) {

//		Uniprot_Refseq_MultipleMapping obj = new Uniprot_Refseq_MultipleMapping("swissprot_refseq_human_NM.txt", "refGene.hg19.NM.bed" , "swissprot_refseq_human_NM_multiple.txt");
		

		Uniprot_Refseq_MultipleMapping obj = new Uniprot_Refseq_MultipleMapping(args[0], args[1] , args[2]);
		
		obj.doProcessing();
	}
}
