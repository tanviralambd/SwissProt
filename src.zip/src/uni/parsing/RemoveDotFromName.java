package uni.parsing;


import java.util.Vector;


import uni.common.CommonFunction;
import uni.constant.ConstantValue;

public class RemoveDotFromName {

	
	String fnmInput;
	String fnmOut;
	
	
	
	void doProcessing()
	{
	
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);
		
		StringBuffer res = new StringBuffer();
		String tmp[];
		String uni, ref;
		
		
		for(int i=0;  i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			uni = tmp[0];
			ref = tmp[1];
			int indexDot = ref.indexOf('.');
			ref = ref.substring(0, indexDot);
			
			res.append(ref + "\t" + uni + "\n");
		}
		
		
		
		CommonFunction.writeContentToFile(this.fnmOut, res+"");
	}
	
	
	
	
	public RemoveDotFromName(String fnmInput, String fnmOut) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOut = fnmOut;
	}




	public static void main(String[] args) {
		
//		RefgeenToUniprot obj = new RefgeenToUniprot(args[0] , args[1]);
		
		RemoveDotFromName obj = new RemoveDotFromName("swissprot_refgene_human_download.txt" , 
				"swissprot_refgene_human.txt");
		
		obj.doProcessing();
		
	}
	
}
