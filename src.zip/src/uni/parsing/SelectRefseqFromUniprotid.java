package uni.parsing;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import uni.common.CommonFunction;
import uni.constant.ConstantValue;

public class SelectRefseqFromUniprotid {



	String bedRefseq;
	String multiple_mapping;
	String inputUniprotId;
	String outputSelectedBed;


	public SelectRefseqFromUniprotid(String bedRefseq, String multiple_mapping,
			String inputUniprotId, String outputSelectedBed) {
		super();
		this.bedRefseq = bedRefseq;
		this.multiple_mapping = multiple_mapping;
		this.inputUniprotId = inputUniprotId;
		this.outputSelectedBed = outputSelectedBed;
	}



	LinkedHashMap<String, Set<String> > lhm_Uni_RefseqMultiple = new LinkedHashMap<String, Set<String>>();
	LinkedHashMap<String, Set<String>> lhm_RefseqName_RefseqLineBed = new LinkedHashMap<String, Set<String>>() ;

	Vector<String> vectSelectedUniID = new Vector<String>();

	void loadrefseqName_BedMapping()
	{

		String tmp[];
		String curLine , curName;
		String  uniprotID, refseqIDWithVersion, refseqIDWithoutVersion;


		/*
		 *  Load refseqName -> set of sequence
		 */
		Vector<String>  vectBED = new Vector<String>();
		vectBED = CommonFunction.readlinesOfAfile( this.bedRefseq);

		for(int i=0; i<vectBED.size();i++)
		{
			curLine = vectBED.get(i) ;
			tmp = ConstantValue.patTab.split(  curLine);
			refseqIDWithoutVersion = tmp[3];


			if(lhm_RefseqName_RefseqLineBed.containsKey(refseqIDWithoutVersion))
			{
				//				System.out.println("Already exist: " + refseqIDWithoutVersion);
				((Set)lhm_RefseqName_RefseqLineBed.get(refseqIDWithoutVersion ) ).add( curLine )  ;
			}else
			{


				Set tmpSet = new LinkedHashSet<String>();
				tmpSet.add(curLine);
				lhm_RefseqName_RefseqLineBed.put(refseqIDWithoutVersion, tmpSet );

			}

		}
		System.out.println("Total unique name in bed file: " + lhm_RefseqName_RefseqLineBed.size());


	}


	void loadUniRefseqMultiple()
	{
		String tmp[] , tmpCommaSep[];
		String curLine , curName;
		String  uniprotID, refseqIDWithoutVersion;
		/*
		 *  Load uniprot -> set of RefseqNM
		 */

		Vector<String>  vectIDmap = new Vector<String>();
		vectIDmap = CommonFunction.readlinesOfAfile( this.multiple_mapping);

		for(int i=0; i<vectIDmap.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectIDmap.get(i));
			uniprotID = tmp[0];
			refseqIDWithoutVersion = tmp[1] ;
			tmpCommaSep = ConstantValue.patSemiColonComma.split(refseqIDWithoutVersion);

			Set tmpSet = new LinkedHashSet<String>();
			for(int k=0; k<tmpCommaSep.length;k++)
			{
				tmpSet.add(tmpCommaSep[k]);
			}


			if(lhm_Uni_RefseqMultiple.containsKey(uniprotID))
			{
				System.out.println("Already exist: " + tmp[0]);


			}else
			{

				lhm_Uni_RefseqMultiple.put( uniprotID, tmpSet );
			}
		}
		System.out.println("Total unique entry in swissprot name: " + lhm_Uni_RefseqMultiple.size());
	}


	void loadSelectedUniid()
	{
		vectSelectedUniID = CommonFunction.readlinesOfAfile(this.inputUniprotId);
	}



	void writeSelected()
	{
		StringBuffer resBuffer = new StringBuffer();

		String curUniid, curRefid, curRefLine;
		String tmp[];


		int trxNoForUni=1;

		for(int i=0 ;   i<vectSelectedUniID.size();i++)
		{

			curUniid = vectSelectedUniID.get(i);
			trxNoForUni=1;
			Set<String> setRefID = lhm_Uni_RefseqMultiple.get(curUniid);

			if(setRefID!=null)
			{

				Iterator itrRefseqID = setRefID.iterator();
				while(itrRefseqID.hasNext())
				{
					curRefid = (String) itrRefseqID.next();


					Set<String> setRefSequence = lhm_RefseqName_RefseqLineBed.get(curRefid);

					if(setRefSequence!=null)
					{
						Iterator itrRefseqLineBed = setRefSequence.iterator();
						while(itrRefseqLineBed.hasNext())
						{
							curRefLine = (String) itrRefseqLineBed.next();	

							tmp = ConstantValue.patWhiteSpace.split(curRefLine);

							tmp[3] = curUniid + "#" + tmp[3]+ "#" + trxNoForUni ;

							StringBuffer tmpBuffer = new StringBuffer();
							for(int step=0 ; step<tmp.length; step++)
							{
								tmpBuffer.append(tmp[step] + "\t");
							}

							resBuffer.append(tmpBuffer+"\n");
							//						resBuffer.append( curRefLine  + "\n");

							trxNoForUni++;
						}
					}else
					{
						System.out.println("No refid found for refID: "+ curRefid);
					}



				}

			}else
			{
				System.out.println("No refid found for uniID: "+ curUniid);
			}




		}// iterating over all selected it


		CommonFunction.writeContentToFile(this.outputSelectedBed, resBuffer+"");
	}

	void doProcessing()
	{


		loadrefseqName_BedMapping();
		loadUniRefseqMultiple();

		loadSelectedUniid();
		writeSelected();

	}



	public static void main(String[] args) {

				SelectRefseqFromUniprotid obj = new SelectRefseqFromUniprotid(args[0], args[1], args[2], args[3]);


		//		SelectRefseqFromUniprotid obj = new SelectRefseqFromUniprotid("refGene.hg19.NM.bed", "swissprot_refseq_human_NM_multiple.txt", "selectedUniprot.id", "selectedUniprot.id.bed");

//		SelectRefseqFromUniprotid obj = new SelectRefseqFromUniprotid("refGene.hg19.NM.bed", "swissprot_refseq_human_NM_multiple.txt", "nature.txt", "nature.txt.bed");

		obj.doProcessing();
	}




}
