

package uni.mapping;
import java.util.Vector;

import uni.common.CommonFunction;
import uni.constant.ConstantValue;


public class Mapping_UniprotACC_Entrezid {

	String fnmAllMapping;
	String fnmOut;
	
	
	
	
	
	public Mapping_UniprotACC_Entrezid(String fnmAllMapping, String fnmOut) {
		super();
		this.fnmAllMapping = fnmAllMapping;
		this.fnmOut = fnmOut;
	}

	void doProcessing()
	{
		
//		UniProtKB-ID
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAllMapping);
		String tmp[];
		
		
		StringBuffer bufRes = new StringBuffer();
		for(int i=0;  i<vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			if( tmp[1].equals("GeneID"))
			{
				bufRes.append(tmp[0]  + "\t"  + tmp[2]  + "\n");
			}
			
		}
		
		CommonFunction.writeContentToFile(this.fnmOut, bufRes+"");
		
	}
	
	public static void main(String[] args) {
		
		Mapping_UniprotACC_Entrezid obj = new Mapping_UniprotACC_Entrezid(args[0], args[1]);

//		Mapping_UniprotACC_UniprotName obj = new Mapping_UniprotACC_UniprotName(
//				"HUMAN_9606_idmapping.dat", 
//				"HUMAN_9606_idmapping.dat_UniAcc_EntrezID.txt");

		
		obj.doProcessing();
	}
	
	
}
