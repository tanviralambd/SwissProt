package uni.bedtools;

import java.util.Vector;

import uni.common.CommonFunction;
import uni.constant.ConstantValue;

public class BedTools_Intergenic {

	
	String finBed;
	String foutIntergenic;
	
	
	
	
	
	public BedTools_Intergenic(String finBed, String foutIntergenic) {
		super();
		this.finBed = finBed;
		this.foutIntergenic = foutIntergenic;
	}

	void doProcessing()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.finBed);
		
		String tmp[];
		String curLine;
		String prevChrm="", curChrm="";
		int prevStart=0,prevEnd=0,curStart=0, curEnd=0 ;
		
		StringBuffer bufResult = new StringBuffer();
		
		for(int i=0; i<vectAll.size();i++)
		{
			curLine = vectAll.get(i);
			tmp = ConstantValue.patTab.split(curLine);
			
			curChrm = tmp[0];
			curStart = Integer.parseInt(tmp[1]);
			curEnd = Integer.parseInt(tmp[2]);
			
			if( !curChrm.equals(prevChrm)) // Start of a chromosome
			{
				System.out.println("Working for chr: " + curLine);
				
				
				prevChrm = curChrm;
				prevStart = curStart;
				prevEnd = curEnd;
				
			}else // Continue in previous chromosome
			{
				
				
				bufResult.append(curChrm +  "\t" + (prevEnd+1)  + "\t" + (curStart-1) + "\n");
				
				prevChrm = curChrm;
				prevStart = curStart;
				prevEnd = curEnd;
				
				
			}
			
			
			prevChrm = curChrm;
		}
		
		
		CommonFunction.writeContentToFile(this.foutIntergenic, bufResult+"");
		
	}
	
	public static void main(String[] args) {
	
//		BedTools_Intergenic obj = new BedTools_Intergenic("/run/media/tanviralam/Data/research/F5shortRNA/TestRIKEN/gencode.v19.annotation.gtf.bed.sorted.merged.bed.sortedByEnd",
//				"/run/media/tanviralam/Data/research/F5shortRNA/TestRIKEN/gencode.v19.annotation.gtf.bed.sorted.merged.bed.sortedByEnd.intergenic");
//		
		
//		BedTools_Intergenic obj = new BedTools_Intergenic("/run/media/tanviralam/Data/research/F5shortRNA/TestRIKEN/test.bed",
//				"/run/media/tanviralam/Data/research/F5shortRNA/TestRIKEN/gencode.v19.annotation.gtf.bed.sorted.merged.bed.sortedByEnd.intergenic");
		
		
		BedTools_Intergenic obj = new BedTools_Intergenic(args[0], args[1]);
		
		obj.doProcessing();
		
	}
}
