package uni.bedtools;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Pattern;

import uni.bean.BedFormat;
import uni.common.CommonFunction;

public class BedTools_CAGEUpstreamNearest {


	String fnmOne;
	String fnmTwo;
	String fnmOut;

	int upstream,downstream;

	HashMap<String, Vector<BedFormat> > mapChrmWisePromoterState = new HashMap<String, Vector<BedFormat>>();
	HashMap<String, Vector<BedFormat> > mapChrmWisePromoterState2 = new HashMap<String, Vector<BedFormat>>();


	public void init(String fnm1, String fnm2, String fnmOut , String up, String down)
	{
		
		this.fnmOne =  fnm1;
		this.fnmTwo =    fnm2;

		this.fnmOut =  fnmOut;		
		this.upstream = Integer.parseInt(up);
		this.downstream = Integer.parseInt(down);

	}


	void makeChrmWisePromoterMap() {
		System.out.println("Extracting info ... ... ... ");
		String strLine = null;
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		int index = 0;

		try {

			FileInputStream fstream = new FileInputStream(fnmOne);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));


			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 3) {
					continue;
				}
				tmp = p.split(strLine);

				try {
					addInChrMap( tmp[0], Integer.parseInt(tmp[1])   , Integer.parseInt(tmp[2])   ,  tmp[3], tmp[4] , tmp[5].charAt(0) , tmp[6], tmp[7] ); // as UCSC startIndex 0 based, endIndex 1 based 

				} catch (Exception e) {
					e.printStackTrace();
				}
				index++;

			}

			System.out.println("Total entry in the file:" + index); //9918801
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}





	void addInChrMap( String chrm, int start, int end,   String name, String score ,char strand , String CDSstart, String CDSend) {

		try {
			BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand, Integer.parseInt(CDSstart) , Integer.parseInt(CDSend) );

			if (mapChrmWisePromoterState.containsKey(chrm)) {
				mapChrmWisePromoterState.get(chrm).add(pm);
			} else {
				Vector<BedFormat> vp = new Vector<BedFormat>();
				vp.add(pm);
				mapChrmWisePromoterState.put(chrm, vp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Err for "+ chrm +"\t"+ start +"\t" + end +"\t" + name +"\t"  + score +"\t"  + strand);
		}


	}


	void addInChrMap2( String chrm, int start, int end,   String name, String score ,char strand) {

		BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand);

		if (mapChrmWisePromoterState2.containsKey(chrm)) {
			mapChrmWisePromoterState2.get(chrm).add(pm);
		} else {
			Vector<BedFormat> vp = new Vector<BedFormat>();
			vp.add(pm);
			mapChrmWisePromoterState2.put(chrm, vp);
		}

	}


	void makeChrmWisePromoterMap2() {
		System.out.println("Extracting second info ... ... ... ");
		String strLine = null;
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		int index = 0;
		try {

			FileInputStream fstream = new FileInputStream(fnmTwo);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 3) {
					continue;
				}
				tmp = p.split(strLine, 7);

				try {

					addInChrMap2 ( tmp[0], Integer.parseInt(tmp[1])   , Integer.parseInt(tmp[2])   ,  tmp[3], tmp[4] , tmp[5].charAt(0)); // as UCSC startIndex 0 based, endIndex 1 based 

				} catch (Exception e) {
					e.printStackTrace();
				}
				index++;

			}

			System.out.println("Total second entry in the file:" + index); //9918801
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	void findDistance_CAGE_TSSbased()
	{
		int minDist = Integer.MAX_VALUE;
		int distTSS_cagemidpoint=0;
		String other=null;
		try {
//			BufferedWriter bwr = new BufferedWriter(new FileWriter( this.fnmOut));
			StringBuffer bufCage_Tss = new StringBuffer();
//			StringBuffer bufTSS_TIS = new StringBuffer();

			Set setChrm = mapChrmWisePromoterState.entrySet();
			Set setChrm2 = mapChrmWisePromoterState2.entrySet();

			int promStartCoord, promEndCoord;
			Iterator it = setChrm.iterator();
			while (it.hasNext()) {
				Map.Entry me = (Map.Entry) it.next();
				String currentChrm = (String)me.getKey();

				Vector<BedFormat> vp = (Vector<BedFormat>) me.getValue();
				Vector<BedFormat> vp2 =  mapChrmWisePromoterState2.get(currentChrm);
				if(vp2==null)
					System.out.println("No peak found for chromosome: "+ currentChrm) ;
				for(int i=0;  i<vp.size() ;i++)
				{
					
					promStartCoord  = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getStart() - upstream    :  vp.get(i).getEnd() - downstream;
					promEndCoord    = (vp.get(i).getStrand()=='+' ) ? vp.get(i).getStart() + downstream  :  vp.get(i).getEnd() + upstream ;
					
					if(vp2 != null)
					{
						minDist = Integer.MAX_VALUE;

						for(int j=0; j<vp2.size();j++)
						{
							if(vp.get(i).getStrand() == vp2.get(j).getStrand())
							{
								
								
								if ( CommonFunction.isOverlap( promStartCoord, promEndCoord ,vp2.get(j).getStart() ,vp2.get(j).getEnd() ) )
								{
								
									
									distTSS_cagemidpoint = Math.abs(      vp.get(i).getTss() - vp2.get(j).getMidPoint()   ) ;
									if(distTSS_cagemidpoint < minDist)
									{
										minDist = distTSS_cagemidpoint ;
										other =  vp2.get(j).getChrom()+"\t" +  vp2.get(j).getMidPoint() + "\t" + (vp2.get(j).getMidPoint()+1) + "\t"+ vp2.get(j).getName() + "\t"  + vp2.get(j).getScore() + "\t" + vp2.get(j).getStrand() ;
									}
									
								}
								
								
							}
						}

						if(minDist != Integer.MAX_VALUE) // no chipSeqPeak in promoter is found
						{
							bufCage_Tss.append(  vp.get(i).getChrom()+"\t" +  vp.get(i).getStart() + "\t" + vp.get(i).getEnd() + "\t" + vp.get(i).getName() + "\t" +  vp.get(i).getScore()+"\t" +vp.get(i).getStrand() + "\t" +
									other + "\t" + minDist +  "\t" + Math.abs( vp.get(i).getTis() - vp.get(i).getTss() )  + "\n"  );
							
//							bufTSS_TIS.append((  vp.get(i).getChrom()+"\t" +  vp.get(i).getStart() + "\t" + vp.get(i).getEnd() + "\t" + vp.get(i).getName() + "\t" +  vp.get(i).getScore()+"\t" +vp.get(i).getStrand() + "\t" +
//									Math.abs(vp.get(i).getTis() - vp.get(i).getTss() )+  "\n" ) );
							
						}


					}

				}

			}


			
			CommonFunction.writeContentToFile(this.fnmOut, bufCage_Tss+"");
//			CommonFunction.writeContentToFile(this.fnmOut+".TSS_TIS.dist", bufTSS_TIS+"");
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}




	}

	void doProcessing()
	{
		makeChrmWisePromoterMap();
		makeChrmWisePromoterMap2();

		findDistance_CAGE_TSSbased();


	}

	public static void main(String[] args) {

		BedTools_CAGEUpstreamNearest obj = new BedTools_CAGEUpstreamNearest();

		obj.init(args[0], args[1], args[2] , args[3] , args[4]);

		obj.doProcessing();




	}


}



