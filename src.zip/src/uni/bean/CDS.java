package uni.bean;

public class CDS {


	String  chrom;
	Integer start;
    Integer end;
    char strand;
	public String getChrom() {
		return chrom;
	}
	public void setChrom(String chrom) {
		this.chrom = chrom;
	}
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getEnd() {
		return end;
	}
	public void setEnd(Integer end) {
		this.end = end;
	}
	public char getStrand() {
		return strand;
	}
	public void setStrand(char strand) {
		this.strand = strand;
	}
	public CDS(String chrom, Integer start, Integer end, char strand) {
		super();
		this.chrom = chrom;
		this.start = start;
		this.end = end;
		this.strand = strand;
	}
	
    
	
	

	
    
    
}
